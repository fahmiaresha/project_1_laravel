<?php $__env->startSection('title','Halaman Home'); ?>

<?php $__env->startSection('konten'); ?>

<div class="container">
   <div class="row">
      <div class="col-10">
  <h1 class ="mt-3">Daftar Mahasiswa </h1>
  <br>
  <table class="table table-bordered">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Nim</th>
      <th scope="col">Nama</th>
      <th scope="col">Alamat</th>
      <th scope="col">Telp</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>

  <tbody>
  <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e($m->Nama); ?></td>
      <td><?php echo e($m->Alamat); ?></td>
      <td><?php echo e($m->Telpon); ?></td>
      <td>
        <a href="" class="badge badge-success">Edit</a>
        <a href="" class="badge badge-danger">Delete</a>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

      </div>
   </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\installaravel\resources\views/template/home.blade.php ENDPATH**/ ?>