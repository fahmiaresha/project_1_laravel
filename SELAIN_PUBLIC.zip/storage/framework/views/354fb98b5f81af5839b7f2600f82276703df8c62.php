<?php $__env->startSection('title','Halaman Sales Detail'); ?>

<?php $__env->startSection('konten'); ?>

<div class="container" style="margin-left: 15px;">
   <div class="row">
      <div class="col-20">
      
  <h2 class ="mt-3">Data Sales Detail</h2>
   <!-- <a href="/sales_detail/create"><button type="button" class="btn btn-primary my-3">Tambah Data</button></a> -->
  
    <font size="2">
      <table class="table table-striped table-bordered mydatatable" style="width:100%;"> </font>
    <thead class="thead-dark">
    <tr>
    <!-- <th  style="text-align:center"  scope="col">#</th> -->
    
      <th  style="text-align:center" scope="col">Nota ID</th>
      <th style="text-align:center"  scope="col">Product Name</th>
      <th style="text-align:center"  scope="col">Quantity</th>
      <th style="text-align:center"  scope="col">Price</th>
      <th style="text-align:center"  scope="col">Discount</th>
      <th style="text-align:center"  scope="col">Total Price</th>
    </tr>
  </thead>

  <tbody>
  <?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td style="text-align:center" ><?php echo e($sales_detail[$key]->nota_id); ?></td>
      <td><?php echo e($sd->product_name); ?></td>
      <td style="text-align:center" ><?php echo e($sd->quantity); ?></td>
      <td style="text-align:center" ><?php echo e($sd->selling_price); ?></td>
      <td style="text-align:center" ><?php echo e($sd->discount); ?></td>
      <td style="text-align:center" ><?php echo e($sd->total_price); ?></td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
  
<div class="container">
      <div class="text-center text-muted"><font size="4">Copyright © 2020 - M.  Fahmi Aresha</font></div>
    </div>

      </div>
   </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tambahscript'); ?>
<script>
     $('.mydatatable').DataTable();
</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master/customer/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\installaravel\resources\views/transaksi/sales_detail/index.blade.php ENDPATH**/ ?>