<!DOCTYPE html>
<html>
<head>
	<title>Membuat Laporan PDF Dengan DOMPDF Laravel</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h5>Membuat Laporan PDF Dengan DOMPDF Laravel</h4>
		<h6><a target="_blank" href="https://www.malasngoding.com/membuat-laporan-…n-dompdf-laravel/">www.malasngoding.com</a></h5>
	</center>

	<table class='table table-bordered'>
		<thead>
			<tr>
            <th scope="col">Status</th>
            <th scope="col"  style="text-align:center" >ID</th>
            <th scope="col"  style="text-align:center" >First Name</th>
            <th scope="col"  style="text-align:center" >Last Name</th>
            <th scope="col"  style="text-align:center" >Phone</th>
            <th scope="col"  style="text-align:center" >Email</th>
            <th scope="col"  style="text-align:center" >Street</th>
            <th scope="col"  style="text-align:center" >City</th>
            <th scope="col"  style="text-align:center" >State</th>
            <th scope="col"  style="text-align:center" >Zip Code</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
            <td  style="text-align:center"><?php echo e($cus->status); ?></td>
            <td  style="text-align:center"><?php echo e($cus->customer_Id); ?></td>
            <td  style="text-align:center"> <?php echo e($cus->first_name); ?></td>
            <td style="text-align:center"><?php echo e($cus->last_name); ?></td>
            <td style="text-align:center"><?php echo e($cus->phone); ?></td>
            <td style="text-align:center"><?php echo e($cus->email); ?></td>
            <td style="text-align:center"><?php echo e($cus->street); ?></td>
            <td style="text-align:center"><?php echo e($cus->city); ?></td>
            <td style="text-align:center"><?php echo e($cus->state); ?></td>
            <td style="text-align:center"><?php echo e($cus->zip_code); ?></td>
				
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\installaravel\resources\views/master/customer/pdf.blade.php ENDPATH**/ ?>