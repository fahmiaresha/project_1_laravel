<?php $__env->startSection('title','Halaman Sales'); ?>

<?php $__env->startSection('konten'); ?>

<div class="container" style="margin-left: 15px;">
   <div class="row">
      <div class="col-20">
  <h2 class ="mt-3">Data Sales</h2>
  
   <!-- Button trigger modal -->
   <?php if(\Session::has('super_admin') || \Session::has('owner') || \Session::has('admin') || \Session::has('kasir')): ?>
<!-- <button type="button" class="btn btn-primary my-3" data-toggle="modal" 
data-target="#exampleModal3">
  Tambah Data Sales
</button> -->
<div class="form-row">
<div class="form-group col-md-4">
<a href="/sales_detail/create"><button type="button" class="btn btn-primary my-3">Tambah Data Sales</button></a>
</div>
<div class="form-group col-md-5">
</div>
<div class="form-group col-md-3">
<a href="/sales_detail/pdf"><button type="button" onclick="tampil_download()" class="btn btn-danger"><svg class="bi bi-download" width="20px" height="20px" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M.5 8a.5.5 0 01.5.5V12a1 1 0 001 1h12a1 1 0 001-1V8.5a.5.5 0 011 0V12a2 2 0 01-2 2H2a2 2 0 01-2-2V8.5A.5.5 0 01.5 8z" clip-rule="evenodd"></path>
  <path fill-rule="evenodd" d="M5 7.5a.5.5 0 01.707 0L8 9.793 10.293 7.5a.5.5 0 11.707.707l-2.646 2.647a.5.5 0 01-.708 0L5 8.207A.5.5 0 015 7.5z" clip-rule="evenodd"></path>
  <path fill-rule="evenodd" d="M8 1a.5.5 0 01.5.5v8a.5.5 0 01-1 0v-8A.5.5 0 018 1z" clip-rule="evenodd"></path>
</svg> Laporan Sales</button></a>
</div>
</div>
<?php endif; ?>

<!-- Modal -->
<div class="modal fade" id="exampleModal3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Insert sales</font></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="post" action="<?php echo e(url('/sales/store')); ?>">
      <?php echo e(csrf_field()); ?>


  <!-- <div class="form-group">
    <label for="customer_id"><font size="4">Customer Id</font></label>
    <input type="text" class="form-control <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
    id="customer_id" placeholder="customer_id@example.com" name="customer_id" value="<?php echo e(old('customer_id')); ?>">
    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div clas="invalid-feedback"><font color="red" size="2"><?php echo e($message); ?></font></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div> -->

  <!-- <div class="form-group">
    <label for="user_id"><font size="4">User Id</font></label>
    <input type="text" class="form-control <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
    id="user_id" placeholder="08xxxxxxxx
     " name="user_id" value="<?php echo e(old('user_id')); ?>">
    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div clas="invalid-feedback"><font color="red" size="2"><?php echo e($message); ?></font></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div> -->

  <div class="form-group ">
    <label for="customer_id"><font size="4">Customer Name</font></label>
    <select class="form-control" id="customer_id" name="customer_id">
    <option disabled selected="">Pilih Customer</option>
      <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($cus -> customer_Id); ?>"><?php echo e($cus->first_name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

  <div class="form-group ">
    <label for="user_id"><font size="4">User Name</font></label>
    <select class="form-control" id="user_id" name="user_id">
    <option disabled selected="">Pilih User</option>
      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($us->user_id); ?>"><?php echo e($us->first_name2); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

 

  

  <div class="form-group">
    <label for="nota_date"><font size="4">Date </font></label>
    <input type="date" class="form-control <?php $__errorArgs = ['nota_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
    id="nota_date" placeholder=" nota_date " name="nota_date" value="">
    <?php $__errorArgs = ['nota_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div class="invalid-feedback"><font color="red" size="2"><?php echo e($message); ?></font></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
  
  <div class="form-group">
    <label for="total_payment"><font size="4">Total Payment</font></label>
    <input type="numeric" class="form-control <?php $__errorArgs = ['total_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
    id="total_payment" placeholder="Total" name="total_payment" value="<?php echo e(old('total_payment')); ?>">
    <?php $__errorArgs = ['total_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div class="invalid-feedback"><font color="red" size="2"><?php echo e($message); ?></font></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
      </div>

      <div class="modal-footer">
        <button type="reset" class="btn btn-danger">Reset</button>
        <button type="submit" class="btn btn-success">Insert</button>
        </form>
      </div>
    </div>
  </div>
</div> 

<?php if(session('status')): ?>
    <font size="4"> 
      <script>
      Swal.fire(
          'Data Berhasil Di Tambahkan!',
          '',
          'success'
        )
    </script>
    </font>
    <?php endif; ?>
   
    <?php if(session('status2')): ?>
    <font size="4"> 
    <script>
      Swal.fire(
        'Data Berhasil Di Update!',
          '',
          'success'
        )
    </script>
    </font>
    <?php endif; ?>

    <?php if(session('status3')): ?>
    <font size="4"> 
    <script>
      Swal.fire(
          'Data Berhasil Di Hapus!',
          '',
          'success'
        )
    </script>
    </font>
    <?php endif; ?>
    <font size="2">
      <table class="table table-striped table-bordered mydatatable" style="width:100%;"> </font>
    <thead class="thead-dark">
    <tr>
    <!-- <th scope="col">#</th> -->
      <th scope="col" style="text-align:center" >Nota ID</th>
      <th scope="col" style="text-align:center" >Customer Name</th>
      <th scope="col" style="text-align:center" >User Name</th>
      <th scope="col" style="text-align:center" >Date</th>
      <th scope="col" style="text-align:center" >Total Payment</th>
      <?php if(\Session::has('super_admin') || \Session::has('owner') || \Session::has('kasir') ): ?>
      <th scope="col" style="text-align:center" >Action</th>
      <?php endif; ?>
    </tr>
  </thead>

  <tbody>
  <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <!-- <th scope="row"> <?php echo e($loop->iteration); ?></th> -->
      <td style="text-align:center"><?php echo e($sl->nota_id); ?></td>
      <td  style="text-align:center"><?php echo e($sl->first_name); ?></td>
      <td  style="text-align:center"><?php echo e($sl->first_name2); ?></td>
      <td style="text-align:center"><?php echo e($sl->nota_date); ?></td>
      <td style="text-align:center"><?php echo e($sl->total_payment); ?></td>
      <?php if(\Session::has('super_admin') || \Session::has('owner') || \Session::has('kasir')): ?>
      <td>
        
        <!-- <a href="/user/edit/<?php echo e($us->user_id); ?>" 
           class="badge badge-success"><svg class="bi bi-pencil" width="25px" height="25px" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M13.293 3.293a1 1 0 011.414 0l2 2a1 1 0 010 1.414l-9 9a1 1 0 01-.39.242l-3 1a1 1 0 01-1.266-1.265l1-3a1 1 0 01.242-.391l9-9zM14 4l2 2-9 9-3 1 1-3 9-9z" clip-rule="evenodd"></path>
  <path fill-rule="evenodd" d="M14.146 8.354l-2.5-2.5.708-.708 2.5 2.5-.708.708zM5 12v.5a.5.5 0 00.5.5H6v.5a.5.5 0 00.5.5H7v.5a.5.5 0 00.5.5H8v-1.5a.5.5 0 00-.5-.5H7v-.5a.5.5 0 00-.5-.5H5z" clip-rule="evenodd"></path>
</svg>Edit</a> -->

<!-- Button trigger modal -->
<button type="button" class="badge badge-success" data-toggle="modal" data-target="#detailModal<?php echo e($sl->nota_id); ?>"><svg class="bi bi-eye" width="22px" height="22px" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.134 13.134 0 001.66 2.043C4.12 11.332 5.88 12.5 8 12.5c2.12 0 3.879-1.168 5.168-2.457A13.134 13.134 0 0014.828 8a13.133 13.133 0 00-1.66-2.043C11.879 4.668 10.119 3.5 8 3.5c-2.12 0-3.879 1.168-5.168 2.457A13.133 13.133 0 001.172 8z" clip-rule="evenodd"></path>
  <path fill-rule="evenodd" d="M8 5.5a2.5 2.5 0 100 5 2.5 2.5 0 000-5zM4.5 8a3.5 3.5 0 117 0 3.5 3.5 0 01-7 0z" clip-rule="evenodd"></path>
</svg>
  Detail
</button>

<!-- Modal -->
<div class="modal fade" id="detailModal<?php echo e($sl->nota_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Sales Detail</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
        <?php $x=$sl->nota_id; ?>
       
        <label for="date"><font size="4"><strong>Nota #<?php echo e($x); ?></strong></font></label>
            <font size="2">
            <table class="table table-striped table-bordered " style="width:0%;"> </font>
          <thead class="thead-dark">
            <tr>
                  <!-- <th style="text-align:center" scope="col">Nota ID</th> -->
                  <th style="text-align:center"  scope="col">Name</th>
                  <th style="text-align:center"  scope="col">Quantity</th>
                  <th style="text-align:center"  scope="col">Price</th>
                  <th style="text-align:center"  scope="col">Discount</th>
                  <th style="text-align:center"  scope="col">Tax</th>
                  <th style="text-align:center"  scope="col">Total Price</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <?php if($sl->nota_id == $sd->nota_id): ?>
                  <!-- <td  style="text-align:center"><?php echo e($sd->nota_id); ?></td> -->
                  <td  style="text-align:center"><?php echo e($sd->product_name); ?></td>
                  <td style="text-align:center" ><?php echo e($sd->quantity); ?></td>
                  <td style="text-align:center" ><?php echo e($sd->selling_price); ?></td>
                  <?php $p=0; ?>
                  <?php $p=(($sd->discount/$sd->total_price)*100) ?>
                  <td style="text-align:center" ><strong><?php echo e($p); ?> %</strong></td>
                  <th style="text-align:center" >10 %</th>
                  <td style="text-align:center" ><?php echo e($sd->total_price); ?></td>
                  <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>  
          </table>
          <div class="container">
          <!-- <br> -->
          <div class="form-row">
          <?php $t=0; ?>
          <?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($sl->nota_id == $sd->nota_id): ?>
             <?php $t=$t+$sd->discount ?>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <label><font size="3"><strong>Total Discount : Rp. <?php echo e($t); ?></strong></font></label>
          </div>

          <?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($sl->nota_id == $sd->nota_id): ?>
          <div class="form-row">
          <label><font size="3"><strong>Total Payment : Rp. <?php echo e($sl->total_payment); ?></strong></font></label>
          </div>
          <?php break; ?>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        <!-- <button type="button" class="btn btn-primary">Close</button> -->
      </div>
    </div>
  </div>
</div>



<!-- MODAL EDIT -->
<!-- Button trigger modal -->
<!-- <button type="button" class="badge badge-success" data-toggle="modal" data-target="#editModal<?php echo e($sl->nota_id); ?>">
<svg class="bi bi-pencil" width="25px" height="25px" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M13.293 3.293a1 1 0 011.414 0l2 2a1 1 0 010 1.414l-9 9a1 1 0 01-.39.242l-3 1a1 1 0 01-1.266-1.265l1-3a1 1 0 01.242-.391l9-9zM14 4l2 2-9 9-3 1 1-3 9-9z" clip-rule="evenodd"></path>
  <path fill-rule="evenodd" d="M14.146 8.354l-2.5-2.5.708-.708 2.5 2.5-.708.708zM5 12v.5a.5.5 0 00.5.5H6v.5a.5.5 0 00.5.5H7v.5a.5.5 0 00.5.5H8v-1.5a.5.5 0 00-.5-.5H7v-.5a.5.5 0 00-.5-.5H5z" clip-rule="evenodd"></path>
</svg>Edit
</button> -->

<!-- Modal -->
<div class="modal fade" id="editModal<?php echo e($sl->nota_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Edit Data Sales</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form method="post" action="<?php echo e(url('/sales/update')); ?>">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="id" value="<?php echo e($sl->nota_id); ?>">
  
  <!-- <div class="form-group">
    <label for="customer_id"><font size="4">Nama Customer</font></label>
    <input type="customer_id" class="form-control <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
    id="customer_id" placeholder="customer_id" name="customer_id" 
    value="<?php echo e($sl->customer_id); ?>" required>
    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div clas="invalid-feedback"><font color="red" size="2"><?php echo e($message); ?></font></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="form-group">
    <label for="user_id"><font size="4">Nama user</font></label>
    <input type="text" class="form-control <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
    id="user_id" placeholder="user_id" name="user_id" 
    value="<?php echo e($sl->user_id); ?>" required>
    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div clas="invalid-feedback"><font color="red" size="2"><?php echo e($message); ?></font></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div> -->

  <div class="form-group ">
    <label for="customer_id"><font size="4">Customer Name</font></label>
    <select class="form-control" id="customer_id" name="customer_id">
    <option disabled selected="">Pilih Customer</option>
      <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($cus -> customer_Id); ?>"><?php echo e($cus->first_name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

  <div class="form-group ">
    <label for="user_id"><font size="4">User Name</font></label>
    <select class="form-control" id="user_id" name="user_id">
    <option disabled selected="">Pilih User</option>
      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($us->user_id); ?>"><?php echo e($us->first_name2); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
 
  <div class="form-group">
    <label for="nota_date"><font size="4">Date</font></label>
    <input type="text" class="form-control <?php $__errorArgs = ['nota_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
    id="nota_date" placeholder="nota_date" name="nota_date" 
    value="<?php echo e($sl->nota_date); ?>" readonly>
    <?php $__errorArgs = ['nota_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div clas="invalid-feedback"><font color="red" size="2"><?php echo e($message); ?></font></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  <div class="form-group">
    <label for="total_payment"><font size="4">Total Payment</font></label>
    <input type="text" class="form-control <?php $__errorArgs = ['total_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
    id="total_payment" placeholder="Total" name="total_payment" 
    value="<?php echo e($sl->total_payment); ?>" >
    <?php $__errorArgs = ['total_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div clas="invalid-feedback"><font color="red" size="2"><?php echo e($message); ?></font></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
      
      </div>
      <div class="modal-footer">
      <button type="submit" class="btn btn-success">Update</button>
      <button type="button" class="btn btn-danger" data-dismiss="modal">Back</button>
</form>
      </div>
    </div>
  </div>
</div>
          
        <!-- Button trigger modal -->
       
<!-- <button type="button" class="badge badge-danger" data-toggle="modal" 
data-target="#deleteModal<?php echo e($sl -> nota_id); ?>"><svg class="bi bi-trash-fill" width="20px" height="20px" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  <path fill-rule="evenodd" d="M4.5 3a1 1 0 00-1 1v1a1 1 0 001 1H5v9a2 2 0 002 2h6a2 2 0 002-2V6h.5a1 1 0 001-1V4a1 1 0 00-1-1H12a1 1 0 00-1-1H9a1 1 0 00-1 1H4.5zm3 4a.5.5 0 01.5.5v7a.5.5 0 01-1 0v-7a.5.5 0 01.5-.5zM10 7a.5.5 0 01.5.5v7a.5.5 0 01-1 0v-7A.5.5 0 0110 7zm3 .5a.5.5 0 00-1 0v7a.5.5 0 001 0v-7z" clip-rule="evenodd"></path>
</svg>Delete</button> -->
        
<!-- Modal -->
<div class="modal fade" id="deleteModal<?php echo e($sl -> nota_id); ?>" tabindex="0" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Konfirmasi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Yakin Ingin Menghapus Data ?
      </div>
      <div class="modal-footer">
        <button type="button" class="badge badge-success">
        <a href="<?php echo e(url('/sales/destroy/'.$sl->nota_id)); ?>">
        <font size="2" color="white">Yes</font></a></button>
        <button type="button" class="badge badge-danger" data-dismiss="modal"><font size="2">No</font></button>
      </div>
    </div>
  </div>
</div> 
      </td>
      <?php endif; ?>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
  
<div class="container">
      <div class="text-center text-muted"><font size="4">Copyright © 2020 - M.  Fahmi Aresha</font></div>
    </div>

      </div>
   </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tambahscript'); ?>
<script>
     $('.mydatatable').DataTable();
        function tampil_download(){
              let timerInterval
              Swal.fire({
                title: 'Please Wait....',
                html: 'Your File Is Downloading!',
                timer: 5000,
                timerProgressBar: true,
                onBeforeOpen: () => {
                  Swal.showLoading()
                  timerInterval = setInterval(() => {
                    const content = Swal.getContent()
                    if (content) {
                      const b = content.querySelector('b')
                      if (b) {
                        b.textContent = Swal.getTimerLeft()
                      }
                    }
                  }, 100)
                },
                onClose: () => {
                  clearInterval(timerInterval)
                }
              }).then((result) => {
                /* Read more about handling dismissals below */
                if (result.dismiss === Swal.DismissReason.timer) {
                  console.log('I was closed by the timer')
                }
              })
        }
</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master/customer/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\installaravel\resources\views/transaksi/sales/index.blade.php ENDPATH**/ ?>