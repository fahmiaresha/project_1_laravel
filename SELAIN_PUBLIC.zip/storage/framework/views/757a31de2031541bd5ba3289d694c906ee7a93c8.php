<?php $__env->startSection('title','Halaman Home '); ?>

<?php $__env->startSection('konten'); ?>
  <div class="container">
   <div class="row">
      <div class="col-10">
  <h1 class ="mt-3">ini adalah halaman home </h1>
      </div>
   </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('penjualan/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\installaravel\resources\views/penjualan/home.blade.php ENDPATH**/ ?>