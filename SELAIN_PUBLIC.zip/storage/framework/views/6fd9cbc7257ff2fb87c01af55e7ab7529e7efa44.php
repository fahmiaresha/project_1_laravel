<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman Register</title>

    <!-- Font Icon -->

    <link rel="stylesheet" href="<?php echo e(asset('asset/login/fonts/material-icon/css/material-design-iconic-font.min.css')); ?>">

    <!-- Main css -->
    <link rel="stylesheet" href="<?php echo e(asset('asset/login/css/style.css')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</head>
<body>
<div class="main"> 
     <!-- Sign up form -->
     <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Sign up</h2>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                        </div>
                         <?php endif; ?>

                        <form action="<?php echo e(url('/registerPost')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        
                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="first_name2" id="name" placeholder="First Name" value="<?php echo e(old('name')); ?>"/>
                            </div>

                            <div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="last_name" id="last_name" placeholder="Last Name" value="<?php echo e(old('name')); ?>"/>
                            </div>
    
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email" value="<?php echo e(old('email')); ?>"/>
                            </div>

                           
                            

                            <div class="form-group">
                                <label for="password"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="password" id="password" placeholder="Password"/>
                            </div>
                            <div class="form-group">
                                <label for="confirmation"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="repeat_password" id="repeat_password" placeholder="Repeat your password"/>
                            </div>

                            <div class="form-group">
                                <select id="job_status" name="job_status" class="form-control <?php $__errorArgs = ['job_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Job Status" value="">
                                    <option disabled selected>Pilih Job Status</option>
                                    <option>Owner</option>
                                    <option>Super Admin</option>
                                    <option>Admin</option>
                                    <option>Kasir</option>
                                    </select>
                            </div>

                            <div class="form-group">
                                <input type="checkbox" name="agree-term" id="agree-term" class="agree-term" checked disabled/>
                                <label for="agree-term" class="label-agree-term" name="Terms_Of_Service" id="Terms_Of_Service" ><span><span></span></span>I agree all statements in Terms of service</label>
                            </div>

                            

                            <div class="form-group form-button">
                            <input type="submit" name="signup" id="signup" class="form-submit" value="Register" >
                            </div>

                            

                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="<?php echo e(asset('asset/login/images/signup-image.jpg')); ?>" alt="sing up image"></figure>
                        <a href="<?php echo e(url('/login')); ?>" class="signup-image-link">I am already member</a>
                    </div>
                </div>
            </div>
        </section>

</div>
<!-- JS -->
<script src="<?php echo e(asset('asset/login/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/login/js/main.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\installaravel\resources\views/template/register.blade.php ENDPATH**/ ?>