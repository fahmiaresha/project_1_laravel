<!DOCTYPE html>
<head>
 <title>Belajar Laravel</title>
</head>
<body>
 <h3>Mengirim data dari Controller ke View</h3>
 <br>
 <p>Menerima data: <?php echo $nama;?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\installaravel\resources\views/showname.blade.php ENDPATH**/ ?>