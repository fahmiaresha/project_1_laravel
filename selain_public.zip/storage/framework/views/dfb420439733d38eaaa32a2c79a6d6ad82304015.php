<!DOCTYPE html>
<head>
 <title>Belajar Laravel</title>
</head>
<body>
 <p>Nama: <?php echo e($nama); ?></p>
 <br>
 //<?php
 //for($i=0; $i<count($matkul); $i++)
 //{
 //echo ($i+1).". $matkul[$i]<br>";
 //}
 //?>

<ol>
 <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <li><?php echo e($mk); ?></li>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ol>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\installaravel\resources\views/matakuliah.blade.php ENDPATH**/ ?>