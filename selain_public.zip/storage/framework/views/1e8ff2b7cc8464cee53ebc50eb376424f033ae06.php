<?php $__env->startSection('title','Halaman Home'); ?>

<?php $__env->startSection('konten'); ?>

<div class="container">
   <div class="row">
      <div class="col-7">
  <h2 class ="mt-3">Daftar Customer</h2>
    <a href="/customer/create" class="btn btn-primary my-3">Tambah Data Customer</a>  
  <table class="table table-bordered">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Customer_id</th>
      <th scope="col">First_name</th>
      <th scope="col">Last_name</th>
      <th scope="col">Phone</th>
      <th scope="col">Email</th>
      <th scope="col">Street</th>
      <th scope="col">City</th>
      <th scope="col">State</th>
      <th scope="col">Zip_code</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>

  <tbody>
  <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"> <?php echo e($loop->iteration); ?></th>
      <td><?php echo e($cus->first_name); ?></td>
      <td><?php echo e($cus->last_name); ?></td>
      <td><?php echo e($cus->phone); ?></td>
      <td><?php echo e($cus->email); ?></td>
      <td><?php echo e($cus->street); ?></td>
      <td><?php echo e($cus->city); ?></td>
      <td><?php echo e($cus->state); ?></td>
      <td><?php echo e($cus->zip_code); ?></td>
      <td>
        <a href="" class="badge badge-success">Edit</a>
        <a href="" class="badge badge-danger">Delete</a>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
  

      </div>
   </div>
  </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('template/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\installaravel\resources\views/template/customer.blade.php ENDPATH**/ ?>