<?php $__env->startSection('title','Halaman Edit Kategori'); ?>

<?php $__env->startSection('konten'); ?>

<div class="container">
   <div class="row">
      <div class="col-4">
  <h2 class ="mt-3"><font size="6">Form Edit Data Kategori</font></h2>
      <form method="post" action="/kategori/update">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PUT')); ?>


  <div class="form-group">
    <label for="category_name"><font size="4">Category Name</font></label>
    <input type="text" class="form-control <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
    id="category_name" name="category_name" 
     value="<?php echo e($kategori->category_name); ?>" required>
    <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <div clas="invalid-feedback"><font color="red" size="2"><?php echo e($message); ?></font></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

   <button type="submit" class="btn btn-primary">Simpan Data!</button>
</form>
      </div>
   </div>
  </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('master/customer/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\installaravel\resources\views/master/categorie/edit.blade.php ENDPATH**/ ?>